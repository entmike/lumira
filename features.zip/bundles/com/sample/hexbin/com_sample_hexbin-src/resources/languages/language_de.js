sap.viz.extapi.env.Language
	.register({
		id: 'de',
		value: {
			IDS_VERSION_PUBLIC: 'Öffentliche Version'
		}
	});