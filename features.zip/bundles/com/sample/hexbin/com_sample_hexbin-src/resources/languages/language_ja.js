sap.viz.extapi.env.Language
	.register({
		id: 'ja',
		value: {
			IDS_VERSION_PUBLIC: '公開バージョン'
		}
	});