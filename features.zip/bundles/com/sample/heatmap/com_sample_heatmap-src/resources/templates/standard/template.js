var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"com.sample.heatmap": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);