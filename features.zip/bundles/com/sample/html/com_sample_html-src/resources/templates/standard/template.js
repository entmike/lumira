var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"com.sample.html": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);