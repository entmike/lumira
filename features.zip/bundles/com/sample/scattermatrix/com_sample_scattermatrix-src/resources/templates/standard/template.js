var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"com.sample.scattermatrix": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);