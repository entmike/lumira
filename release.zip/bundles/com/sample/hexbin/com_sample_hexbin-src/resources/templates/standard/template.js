var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"com.sample.hexbin": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);